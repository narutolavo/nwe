from nwe import gurafikkuu

# __version__ = "1.0.3"
# __author__ = "narutolavo"
# __all__ = ['nwe','main']

