import sys
from nwe import gurafikkuu


gurafikkuu.main()
